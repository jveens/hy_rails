require 'minitest/autorun'
require 'rack/test'
require './app'

class AppTest < MiniTest::Test
  include Rack::Test::Methods

  def app
    Sinatra::Application
  end

  def test_hackeryou_endpoint
  	response = get('/hackeryou')
  	assert_equal("Is Awesome!", response.body)
  end

  def test_name 
  	response = get('/hi', name: 'Ryan') 
  	assert_equal("You did it Ryan!", response.body)
  end

  def test_add_exists 
  	response = get('/add')
  	assert_equal(200, response.status)
  end

  def test_adding_1_and_1
  	response = get('/add', a: '1', b: '1')
  	assert_equal('2', response.body)
  end

  def test_adding_2_and_2
  	response = get('/add', a: '2', b: '2')
  	assert_equal('4', response.body)
  end

  def test_hello_endpoint
  	response = get('/hello')
  	assert_equal(200, response.status)
  end

  def test_hello_content
  	response = get('/hello')
  	assert_equal("Hello, minitest!", response.body)
  end

  def test_day_endpoint
  	response = get("/day")
  	assert_equal(200, response.status)
  end

  def test_sunday_day
  	response = get('/day', d: '0')
  	assert_equal('Sunday', response.body)
  end

  def test_monday_day
  	response = get('/day', d: '1')
  	assert_equal('Monday', response.body)
  end

  def test_tuesday_day
  	response = get('/day', d: '2')
  	assert_equal('Tuesday', response.body)
  end

  def test_wednesday_day
  	response = get('/day', d: '3')
  	assert_equal('Wedneday', response.body)
  end

  def test_thursday_day
  	response = get('/day', d: '4')
  	assert_equal('Thursday', response.body)
  end

  def test_friday_day
  	response = get('/day', d: '5')
  	assert_equal('Friday', response.body)
  end

  def test_saturday_day
  	response = get('/day', d: '6')
  	assert_equal('Friday', response.body)
  end

  # def test_params_exist
  # 	response = get('/day', d: 'd')
  # 	assert_equal('d', response.body)
  # end

  # def test_params_is_typeof_integer
  # 	response = get('/day', d: 'd')
  # 	assert(response.body.integer?)
  # end




end

