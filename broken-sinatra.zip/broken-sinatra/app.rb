require 'sinatra'
require 'sinatra/reloader'
require 'json'

get '/now' do
  "The current time is:  ?"
end

get '/hackeryou' do
  "Is Awesome!"
end

get '/hi/?:name?' do
  "You did it " + params[:name] + "!"
end

post '/users' do
  "You posted the following data: #{params.inspect}"
end

post '/books' do
  data = JSON.parse(request.body.read)

  erb :books, locals: {data: data}
end

get '/add' do
	result = params[:a].to_i + params[:b].to_i
	result.to_s
end

get '/hello' do
	"Hello, minitest!"
end

get '/day?:d?' do

	day = params[:d].to_i

	if day == 0
		"Sunday"
	elsif day == 1
		"Monday"
	elsif day == 2
		"Tuesday"
	elsif day == 3
		"Wednesday"
	elsif day == 4
		"Thursday"
	elsif day == 5
		"Friday"
	elsif day == 6
		"Saturday"
	end
		
end

# get '/day?:d?' do
# 	params[:d]
# end

